int main() {
  int x = 10, y = 1 + 2;
  y = y + 10;
  x = x + y;
  return x;
}