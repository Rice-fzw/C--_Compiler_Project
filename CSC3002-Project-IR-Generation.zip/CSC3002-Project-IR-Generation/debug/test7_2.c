int main() {
  while (1) {
    int a = 1, b = 2;
    {
      if (a == 1) {
        while (a < b) {
          while (a < b || b - 1 == 0) {
            a = a + 1;
          }
          b = 1;
          a = a + 1;
          if (3) continue;
        }
      } else if (b == 6) {
        break;
      }
      int b = 6;
      if (b == 6) return 8 * (10 || b);
      else while (0);
    }
  }
  return -1;
}