int main() {
  return +(- -!6);
}