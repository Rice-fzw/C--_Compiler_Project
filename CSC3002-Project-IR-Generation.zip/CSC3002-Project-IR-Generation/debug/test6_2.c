int main() {
  int a = 10;
  if (a > 1) {
    a = a - 1;
    int a = 5;
    if (a < -1) {
      return 10;
    } else {
      int a;
      a = 98;
    }
  }
  if (a == 9) {
    int b = a - 1;
    int a = b - 1;
    if (a != b) {
      if (!a) {
        return 0;
      }
      return a;
    } else {
      return b;
    }
  }
  return -1;
}